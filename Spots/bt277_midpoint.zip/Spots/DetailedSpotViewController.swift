//
//  DetailedSpotViewController.swift
//  Spots
//
//  Created by Productivity on 11/18/19.
//  Copyright © 2019 Productivity. All rights reserved.
//

import UIKit

class DetailedSpotViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    

}
